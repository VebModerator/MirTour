$(document).ready(function() {
    $('#registrationForm').on('submit', function(e) {
        e.preventDefault();

        const username = $('#regUsername').val();
        const email = $('#regEmail').val();
        const password = $('#regPassword').val();
        const confirmPassword = $('#regConfirmPassword').val();

        if (password !== confirmPassword) {
            alert('Пароли не совпадают!');
            return;
        }

        if (password.length < 6) {
            alert('Пароль должен содержать минимум 6 символов!');
            return;
        }

        // Отправка данных на сервер PHP через AJAX
        $.ajax({
            url: 'register.php', // путь к вашему PHP файлу
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                username: username,
                email: email,
                password: password
            }),
            success: function(response) {
                alert(response.message);
                window.location.href = 'login.html'; // перенаправление после успешной регистрации
            },
            error: function(xhr) {
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    alert(xhr.responseJSON.message);
                } else {
                    alert('Произошла ошибка при регистрации');
                }
            }
        });
    });
});